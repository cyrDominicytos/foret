---
name: Feature request
about: Suggest an idea for this project
title: "[Feature Request]"
labels: Feature Request

---

# Feature Request

### What's the feature you think Backpack should have?

??

### Have you already implemented a prototype solution, for your own project?

??

### Do you see this as a core feature or an add-on?

??
